/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TestMAE.cpp
 * Author: snir2g2
 * 
 * Created on 12 mars 2018, 11:03
 */

#include "TestMAE.h"
#include <iostream>
using namespace std;


TestMAE::TestMAE() {
}

TestMAE::TestMAE(const TestMAE& orig) {
}

TestMAE::~TestMAE() {
}

TestMAE::nouvelEtat(Etat e) {
    
    if (e != etat) {
            traiterEtat(Mode.EXIT);
            // on doit toujours revenir à un état de suivi normal
            if (e == Etat.STANDARD) {
                if (connexionOBD2)
                    etat = Etat.NORMAL;
                else
                    etat = Etat.DEGRADE;
            }
            else 
                etat = e;
            traiterEtat(Mode.ENTRY);
            traiterEtat(Mode.DO);
            chgtModeSrv = false;
        }
}


TestMAE::traiterEvenement(Event ev) {
   
    switch (etat) {
            case INIT:
                nouvelEtat(Etat.INIT);
                break;
            case NORMAL:
                switch (ev) {
                    case DMD_GPS:
                        nouvelEtat(Etat.DMD_GPS);
                        break;
                    case MODE_GPS:
                        nouvelEtat(Etat.GPS);
                        break;
                    case BLUETOOTH_OFF:
                        nouvelEtat(Etat.DEGRADE);
                        break;                   
                    case BATT_LOW:
                        nouvelEtat(Etat.ECO);
                        break;
                    case MODE_SLEEP:
                        nouvelEtat(Etat.SLEEP);
                        break;
                    case MODE_MAINTENANCE:
                        nouvelEtat(Etat.MAINTENANCE);
                        break;
                    case MODE_RESET:
                        nouvelEtat(Etat.INIT);
                        break;
                }
                break;
            case DEGRADE:
                switch (ev) {
                    case DMD_GPS:
                        nouvelEtat(Etat.DMD_GPS);
                        break;
                    case MODE_GPS:
                        nouvelEtat(Etat.GPS);
                        break;
                    case BLUETOOTH_ON:
                        nouvelEtat(Etat.NORMAL);
                        break;
                    case BATT_LOW:
                        nouvelEtat(Etat.ECO);
                        break;
                    case MODE_SLEEP:
                        nouvelEtat(Etat.SLEEP);
                        break;
                    case MODE_MAINTENANCE:
                        nouvelEtat(Etat.MAINTENANCE);
                        break;
                    case MODE_RESET:
                        nouvelEtat(Etat.INIT);
                        break;
                }
                break;
            case DMD_GPS :
                nouvelEtat(Etat.DMD_GPS);
                break;
            case GPS :
                switch (ev) {
                    case MODE_STANDARD:
                        nouvelEtat(Etat.STANDARD);
                        break;
                    case MODE_SLEEP:
                        nouvelEtat(Etat.SLEEP);
                        break;
                    case MODE_MAINTENANCE:
                        nouvelEtat(Etat.MAINTENANCE);
                        break;
                    case MODE_RESET:
                        nouvelEtat(Etat.INIT);
                        break;
                    }
                break;
            case SLEEP :
                switch (ev) {
                    case MODE_STANDARD:
                        nouvelEtat(Etat.STANDARD);
                        break;                        
                    case MODE_MAINTENANCE:
                        nouvelEtat(Etat.MAINTENANCE);
                        break;
                    }
                break;
            case MAINTENANCE :
                switch (ev) {
                    case MODE_RESET:
                        nouvelEtat(Etat.INIT);
                        break;
                    case MODE_STANDARD:
                        nouvelEtat(Etat.STANDARD);
                        break;
                    }
                break;
        }
    
    
}

TestMAE::traiterEtat(Mode mode) {
    switch (etat) {
            case INIT:
                switch (mode) {
                    case ENTRY:
                        break;
                    case DO:
                        cout << "RESET de la MAE" << endl;
                        cout << "Initialisation" << endl;
                        nouvelEtat(Etat.STANDARD);
                        break;
                    case EXIT:
                        break;
                }
                break;
            case NORMAL:
                switch (mode) {
                    case ENTRY:
                        if (chgtModeSrv)
                            dureeEnMs = 0;
                        break;
                    case DO:
                        if ((dureeEnMs % tempoMessage) == 0) {
                            cout << "Envoi d'un message NORMAL" << endl;
                           // sigfox.envoyer(Message.normal(
                             //   connexionOBD2, 
                               // 0, 
                                //dpVoiture.getCodeDefauts(), 
                                //(int)dpVoiture.getCompteur(),
                                //dpVoiture.getConsoMoyenne(), 
                                //dpVoiture.getVitesseMoyenne(),
                                //dpVoiture.getRegimeMoyen())
                          //  );
                        }
                        break;
                    case EXIT:
                        break;
                }
                break;
            case DEGRADE:
                switch (mode) {
                    case ENTRY:
                        if (chgtModeSrv)
                            dureeEnMs = 0;
                        break;
                    case DO:
                        if ((dureeEnMs % tempoMessage) == 0) {
                            cout << "Envoi d'un message DEGRADE" << endl;
                            //sigfox.envoyer(Message.degrade(connexionOBD2));
                        }
                        break;
                    case EXIT:
                        break;
                }
                break;
            case DMD_GPS:
                switch (mode) {
                    case ENTRY:
                        dureeEnMs = 0;
                        break;
                    case DO:
                        cout << "Envoi d'un message DMD_GPS" << endl;
                        //sigfox.envoyer(Message.gps(gps));
                        chgtModeSrv = false;
                        nouvelEtat(Etat.STANDARD);
                        break;
                    case EXIT:
                        break;
                }
                break;
            case GPS:
                switch (mode) {
                    case ENTRY:
                        dureeEnMs = 0;
                        break;
                    case DO:
                        if ((dureeEnMs % tempoMessage) == 0) {
                            cout << "Envoi d'un message GPS" << endl;
                            //sigfox.envoyer(Message.gps(gps));
                        }
                        break;
                    case EXIT:
                        break;
                }
                break;
            case SLEEP:
                switch (mode) {
                    case ENTRY:
                        cout << "Envoi d'un message SLEEP" << endl;
                        //sigfox.envoyer(Message.eco(connexionOBD2));
                        break;
                    case DO:
                        cout << "Mode SLEEP" << endl;
                        break;
                }
                break;
            case MAINTENANCE:
                switch (mode) {
                    case ENTRY:
                        // afficher un id sur la console
                        cout << "Envoi d'un message MAINTENANCE" << endl;
                        break;
                    case DO:
                        cout << "Mode MAINTENANCE" << endl;
                        break;
                    case EXIT:
                        break;
                }
                break;
            case RESET:
                switch (mode) {
                    case ENTRY: 
                        break;
                    case DO:                            
                        nouvelEtat(Etat.INIT);
                      
                        break;
                    case EXIT:
                        break;
                }
                break;
        }
}

TestMAE::getEtat() {
    
    return this->etat;
    
}