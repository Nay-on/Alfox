/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TestMAE.cpp
 * Author: snir2g2
 * 
 * Created on 12 mars 2018, 11:03
 */

#include "Global.h"
#include <iostream>
using namespace std;

bool connexionOBD2 = false;

void traiterEtat(Mode mode);

void nouvelEtat(Etat e) {
    
    if (e != etat) {
        traiterEtat(EXIT);
        // on doit toujours revenir à un état de suivi normal
        if (e == STANDARD) {
            if (connexionOBD2)
                etat = NORMAL;
            else
                etat = DEGRADE;
        }
        else 
            etat = e;
        traiterEtat(ENTRY);
        traiterEtat(DO);
        chgtModeSrv = false;
    }
}

void traiterEvenement(Event ev) {
   
    switch (etat) {
            case INIT:
                nouvelEtat(INIT);
                break;
            case NORMAL:
                switch (ev) {
                    case MODE_DMD_GPS:
                        nouvelEtat(DMD_GPS);
                        break;
                    case MODE_GPS:
                        nouvelEtat(GPS);
                        break;
                    case BLUETOOTH_OFF:
                        nouvelEtat(DEGRADE);
                        break;                                                
                    case MODE_DORMIR:
                        nouvelEtat(DORMIR);
                        break;
                    case MODE_MAINTENANCE:
                        nouvelEtat(MAINTENANCE);
                        break;
                    case MODE_INIT:
                        nouvelEtat(INIT);
                        break;
                }
                break;
            case DEGRADE:
                switch (ev) {
                    case MODE_DMD_GPS:
                        nouvelEtat(DMD_GPS);
                        break;
                    case MODE_GPS:
                        nouvelEtat(GPS);
                        break;
                    case BLUETOOTH_ON:
                        nouvelEtat(NORMAL);
                        break;
                   
                    case MODE_DORMIR:
                        nouvelEtat(DORMIR);
                        break;
                    case MODE_MAINTENANCE:
                        nouvelEtat(MAINTENANCE);
                        break;
                    case MODE_INIT:
                        nouvelEtat(INIT);
                        break;
                }
                break;
            case DMD_GPS :
                nouvelEtat(DMD_GPS);
                break;
            case GPS :
                switch (ev) {
                    case MODE_STANDARD:
                        nouvelEtat(STANDARD);
                        break;
                    case MODE_DORMIR:
                        nouvelEtat(DORMIR);
                        break;
                    case MODE_MAINTENANCE:
                        nouvelEtat(MAINTENANCE);
                        break;
                    case MODE_INIT:
                        nouvelEtat(INIT);
                        break;
                    }
                break;
            case DORMIR :
                switch (ev) {
                    case MODE_STANDARD:
                        nouvelEtat(STANDARD);
                        break;                        
                    case MODE_MAINTENANCE:
                        nouvelEtat(MAINTENANCE);
                        break;
                    }
                break;
            case MAINTENANCE :
                switch (ev) {
                    case MODE_INIT:
                        nouvelEtat(INIT);
                        break;
                    case MODE_STANDARD:
                        nouvelEtat(STANDARD);
                        break;
                    }
                break;
        }
    
    
}

void traiterEtat(Mode mode) {
    switch (etat) {
        case INIT:
            switch (mode) {
                case ENTRY:
                    break;
                case DO:
                    cout << "Initialisation" << endl;
                    nouvelEtat(STANDARD);
                    break;
                case EXIT:
                    break;
            }
            break;
        case NORMAL:
            switch (mode) {
                case ENTRY:
                    if (chgtModeSrv)
                        dureeCumulee = 0;
                    break;
                case DO:
                    if ((dureeCumulee % tempoMessage) == 0) {
                        cout << "Envoi d'un message NORMAL" << endl;
                       // sigfox.envoyer(Message.normal(
                         //   connexionOBD2, 
                           // 0, 
                            //dpVoiture.getCodeDefauts(), 
                            //(int)dpVoiture.getCompteur(),
                            //dpVoiture.getConsoMoyenne(), 
                            //dpVoiture.getVitesseMoyenne(),
                            //dpVoiture.getRegimeMoyen())
                      //  );
                    }
                    break;
                case EXIT:
                    break;
            }
            break;
        case DEGRADE:
            switch (mode) {
                case ENTRY:
                    if (chgtModeSrv)
                        dureeCumulee = 0;
                    break;
                case DO:
                    if ((dureeCumulee % tempoMessage) == 0) {
                        cout << "Envoi d'un message DEGRADE" << endl;
                        //sigfox.envoyer(Message.degrade(connexionOBD2));
                    }
                    break;
                case EXIT:
                    break;
            }
            break;
        case DMD_GPS:
            switch (mode) {
                case ENTRY:
                    dureeCumulee = 0;
                    break;
                case DO:
                    cout << "Envoi d'un message DMD_GPS" << endl;
                    //sigfox.envoyer(Message.gps(gps));
                    chgtModeSrv = false;
                    nouvelEtat(STANDARD);
                    break;
                case EXIT:
                    break;
            }
            break;
        case GPS:
            switch (mode) {
                case ENTRY:
                    dureeCumulee = 0;
                    break;
                case DO:
                    if ((dureeCumulee % tempoMessage) == 0) {
                        cout << "Envoi d'un message GPS" << endl;
                        //sigfox.envoyer(Message.gps(gps));
                    }
                    break;
                case EXIT:
                    break;
            }
            break;
        case DORMIR:
            switch (mode) {
                case ENTRY:
                    cout << "Envoi d'un message DORMIR" << endl;
                    //sigfox.envoyer(Message.eco(connexionOBD2));
                    break;
                case DO:                   
                    break;
            }
            break;
        case MAINTENANCE:
            switch (mode) {
                case ENTRY:
                    // afficher un id sur la console
                    cout << "Envoi d'un message MAINTENANCE" << endl;
                    break;
                case DO:
                    break;
                case EXIT:
                    break;            
            }
            break;
    }
}

int main(int argc, char** argv) {
    etat = START;
    dureeCumulee = 0;
    tempoMessage = 1000;
    dureeLoop = 1;
    chgtModeSrv = false;
    
    connexionOBD2 = false;
    
    nouvelEtat(INIT);                      

    connexionOBD2 = true;
    traiterEvenement(BLUETOOTH_ON);

    traiterEvenement(MODE_GPS);
    
    traiterEvenement(MODE_STANDARD);

    connexionOBD2 = false;
    traiterEvenement(BLUETOOTH_OFF);

    traiterEvenement(MODE_GPS);
    
    traiterEvenement(MODE_STANDARD);

    traiterEvenement(MODE_DMD_GPS);

    connexionOBD2 = true;
    traiterEvenement(BLUETOOTH_ON);
    
    traiterEvenement(MODE_DORMIR);

    connexionOBD2 = false;
    traiterEvenement(BLUETOOTH_OFF);

    traiterEvenement(MODE_STANDARD);
    
    traiterEvenement(MODE_MAINTENANCE);
    
    traiterEvenement(MODE_INIT);
    //L'état du boitier repasse en mode standard entre les deux reset
    traiterEvenement(MODE_INIT);

    connexionOBD2 = true;
    traiterEvenement(BLUETOOTH_ON);
    
    traiterEvenement(MODE_INIT);
    
    traiterEvenement(MODE_GPS);
    
    traiterEvenement(MODE_INIT);
      
    return 0;
}


