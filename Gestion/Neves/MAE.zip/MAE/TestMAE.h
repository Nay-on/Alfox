/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TestMAE.h
 * Author: snir2g2
 *
 * Created on 12 mars 2018, 11:03
 */
#include <string>
#include <iostream>
using namespace std;


#ifndef TESTMAE_H
#define TESTMAE_H

class TestMAE {
public:
    TestMAE();
    TestMAE(const TestMAE& orig);
    virtual ~TestMAE();
    
    static enum Etat { STANDARD, NORMAL, DEGRADE, DMD_GPS, GPS, ECO,
                        MAINTENANCE, RESET, INIT, SLEEP, DATA };
                        
    string strEtats = { "STANDARD", "NORMAL", "DEGRADE", "DMD_GPS",
                 "GPS", "ECO", "MAINTENANCE", "RESET", "INIT", "SLEEP", "DATA"};
   
    static enum Event { MODE_STANDARD, MODE_DMD_GPS, MODE_GPS, MODE_ECO,
                        MODE_MAINTENANCE, MODE_RESET,  MODE_SLEEP, MODE_DATA,
                        FIN_TEMPO, BLUETOOTH_ON, BLUETOOTH_OFF, 
                        BATT_LOW, BATT_NORMAL};
                        
    enum Mode { ENTRY, DO, EXIT };
    
    void nouvelEtat(Etat e); 
    void traiterEvenement(Event ev);
    void traiterEtat(Mode mode);
    Etat getEtat();
    
    
private:
    
    Etat etat = Etat.RESET;
    bool chgtModeSrv = false;
    static bool connexionOBD2 = true;
    long dureeEnMs = 0;                 // duree de la loop()
    int tempoMessage = 12000;           // un msg toute les 12 secondes (theorie : 12mn)
    int tempoEco = 10*tempoMessage;    // 10 fois moins de msg en mode ECO
    int dureeLoop = tempoMessage/100;   // 100 acquisitions entre deux messages
    

};

#endif /* TESTMAE_H */

