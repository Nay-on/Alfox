/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: snir2g2
 *
 * Created on 12 mars 2018, 11:02
 */

#include <cstdlib>
#include "TestMAE.h"
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

        TestMAE *mae = new TestMAE();
        mae->nouvelEtat(mae->INIT);
                       
        connexionOBD2 = false;
        mae.traiterEvenement(Event.BLUETOOTH_OFF);
        
        connexionOBD2 = true;
        mae.traiterEvenement(Event.BLUETOOTH_ON);
        
        mae.traiterEvenement(Event.MODE_GPS);
        mae.traiterEvenement(Event.MODE_STANDARD);
        
        connexionOBD2 = false;
        mae.traiterEvenement(Event.BLUETOOTH_OFF);
        
        mae.traiterEvenement(Event.MODE_GPS);
        mae.traiterEvenement(Event.MODE_STANDARD);
        
        mae.traiterEvenement(Event.DMD_GPS);
        
        connexionOBD2 = true;
        mae.traiterEvenement(Event.BLUETOOTH_ON);
        mae.traiterEvenement(Event.MODE_SLEEP);
        
        connexionOBD2 = false;
        mae.traiterEvenement(Event.BLUETOOTH_OFF);
        
        mae.traiterEvenement(Event.MODE_STANDARD);
        mae.traiterEvenement(Event.MODE_MAINTENANCE);
        mae.traiterEvenement(Event.MODE_RESET);
        //L'état du boitier repasse en mode standard entre les deux reset
        mae.traiterEvenement(Event.MODE_RESET);
        
        connexionOBD2 = true;
        mae.traiterEvenement(Event.BLUETOOTH_ON);
        mae.traiterEvenement(Event.MODE_RESET);
        mae.traiterEvenement(Event.MODE_GPS);
        mae.traiterEvenement(Event.MODE_RESET);
      
    return 0;
}

